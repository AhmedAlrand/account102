package com.example.financial;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class FinancialManagementApp extends Application {
    private static final Logger LOGGER = LoggerFactory.getLogger(FinancialManagementApp.class);
    private static final int SCHEDULER_POOL_SIZE = 1;
    private static final long SCHEDULER_INTERVAL_MINUTES = 1440; // 1 day
    public static final ExecutorService executor = Executors.newFixedThreadPool(10);
    private ResourceBundle messages;
    private ScheduledExecutorService scheduler;
    private DatabaseService dbService;
    private AuditService auditService;
    private ExchangeRateService exchangeRateService;
    private String currentUser;
    private final AtomicBoolean isDisposed = new AtomicBoolean(false);
    private Label statusLabel;
    private ProgressBar progressBar;

    @Override
    public void start(Stage primaryStage) {
        dbService = new DatabaseService();
        auditService = new AuditService(dbService);
        exchangeRateService = new ExchangeRateService();
        currentUser = "user"; // Default for testing; replace with login logic later
        setLanguage("en");

        BorderPane root = new BorderPane();
        HBox topBar = createTopBar();
        TabPane tabPane = createTabPane();
        HBox statusBar = createStatusBar();

        root.setTop(topBar);
        root.setCenter(tabPane);
        root.setBottom(statusBar);

        Scene scene = new Scene(root, 1200, 900);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        primaryStage.setTitle(messages.getString("title", "Financial Management"));
        primaryStage.setScene(scene);
        primaryStage.show();

        configureDatabase(primaryStage);
        startScheduledTasks();
    }

    private void setLanguage(String language) {
        try {
            messages = ResourceBundle.getBundle("messages", Locale.forLanguageTag(language));
        } catch (Exception e) {
            LOGGER.error("Error loading language properties for {}", language, e);
            messages = ResourceBundle.getBundle("messages", Locale.ENGLISH);
        }
        updateUIWithMessages();
    }

    private void updateUIWithMessages() {
        if (statusLabel != null) {
            statusLabel.setText(messages.getString("statusReady", "Ready"));
        }
        Stage stage = (Stage) statusLabel.getScene().getWindow();
        if (stage != null) {
            stage.setTitle(messages.getString("title", "Financial Management"));
        }
        TabPane tabPane = (TabPane) ((BorderPane) statusLabel.getScene().getRoot()).getCenter();
        if (tabPane != null) {
            tabPane.getTabs().get(0).setText(messages.getString("dashboard", "Dashboard"));
            tabPane.getTabs().get(1).setText(messages.getString("invoices", "Invoices"));
            tabPane.getTabs().get(2).setText(messages.getString("recurringInvoices", "Recurring Invoices"));
            tabPane.getTabs().get(3).setText(messages.getString("inventory", "Inventory"));
            tabPane.getTabs().get(4).setText(messages.getString("attachments", "Attachments"));
            tabPane.getTabs().get(5).setText(messages.getString("customersSuppliers", "Customers & Suppliers"));
            tabPane.getTabs().get(6).setText(messages.getString("expenses", "Expenses"));
            tabPane.getTabs().get(7).setText(messages.getString("reports", "Reports"));
            tabPane.getTabs().get(8).setText(messages.getString("adjustments", "Adjustments"));
            tabPane.getTabs().get(9).setText(messages.getString("auditTrail", "Audit Trail"));
        }
    }

    private void configureDatabase(Stage stage) {
        DatabaseConfigDialog configDialog = new DatabaseConfigDialog(stage, messages);
        configDialog.showAndWait();
        if (!configDialog.isConfirmed()) {
            stage.close();
        }
    }

    private HBox createTopBar() {
        HBox topBar = new HBox(10);
        topBar.setPadding(new javafx.geometry.Insets(5));

        ComboBox<String> themeCombo = new ComboBox<>();
        themeCombo.getItems().addAll("Light", "Dark");
        themeCombo.setValue("Light");
        themeCombo.setOnAction(e -> changeTheme(themeCombo.getValue()));
        topBar.getChildren().add(themeCombo);

        ComboBox<String> languageCombo = new ComboBox<>();
        languageCombo.getItems().addAll("English", "Arabic");
        languageCombo.setValue("English");
        languageCombo.setOnAction(e -> setLanguage(languageCombo.getValue().equals("English") ? "en" : "ar"));
        topBar.getChildren().add(languageCombo);

        Button newInvoiceButton = new Button(messages.getString("newInvoice", "New Invoice"));
        newInvoiceButton.setOnAction(e -> openNewInvoiceWindow());
        topBar.getChildren().add(newInvoiceButton);

        Button markPaymentButton = new Button(messages.getString("markPaymentReceived", "Mark Payment Received"));
        markPaymentButton.setOnAction(e -> markPaymentReceived());
        topBar.getChildren().add(markPaymentButton);

        MenuButton databaseMenuButton = new MenuButton(messages.getString("database", "Database"));
        MenuItem changeDbItem = new MenuItem(messages.getString("changeDatabase", "Change Database"));
        changeDbItem.setOnAction(e -> changeDatabase());
        MenuItem newDbItem = new MenuItem(messages.getString("newDatabase", "New Database"));
        newDbItem.setOnAction(e -> createNewDatabase());
        databaseMenuButton.getItems().addAll(changeDbItem, newDbItem);
        topBar.getChildren().add(databaseMenuButton);

        return topBar;
    }

    private TabPane createTabPane() {
    TabPane tabPane = new TabPane();
    tabPane.getTabs().addAll(
        new Tab(messages.getString("dashboard", "Dashboard"), new CustomDashboardPane(messages, dbService, auditService, exchangeRateService)),
        new Tab(messages.getString("invoices", "Invoices"), new InvoicePane(messages, dbService, auditService, exchangeRateService, false)),
        new Tab(messages.getString("recurringInvoices", "Recurring Invoices"), new RecurringInvoicePane(messages, dbService, auditService)),
        new Tab(messages.getString("inventory", "Inventory"), new InventoryPane(messages, dbService, auditService)),
        new Tab(messages.getString("attachments", "Attachments"), new AttachmentPane(messages, dbService, auditService)),
        new Tab(messages.getString("customersSuppliers", "Customers & Suppliers"), new ContactsPane(messages, dbService, auditService)),
        new Tab(messages.getString("expenses", "Expenses"), new ExpensesPane(messages, dbService, auditService)),
        new Tab(messages.getString("reports", "Reports"), new ReportPane(messages, dbService, auditService)), // Updated to ReportPane
        new Tab(messages.getString("adjustments", "Adjustments"), new AdjustmentsPane(messages, dbService, auditService)),
        new Tab(messages.getString("auditTrail", "Audit Trail"), new AuditTrailPane(messages, dbService, auditService))
    );
    tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
    restrictAccessBasedOnRole(tabPane, currentUser);
    return tabPane;
}

    private HBox createStatusBar() {
        HBox statusBar = new HBox(10);
        statusBar.setPadding(new javafx.geometry.Insets(5));
        statusLabel = new Label(messages.getString("statusReady", "Ready"));
        progressBar = new ProgressBar();
        progressBar.setVisible(false);
        statusBar.getChildren().addAll(statusLabel, progressBar);
        return statusBar;
    }

    private void changeTheme(String theme) {
        Scene scene = statusLabel.getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        if ("Dark".equals(theme)) {
            scene.getStylesheets().add(getClass().getResource("/dark-theme.css").toExternalForm());
        }
    }

    private void openNewInvoiceWindow() {
        Stage newStage = new Stage();
        newStage.setTitle(messages.getString("newInvoice", "New Invoice"));
        InvoicePane invoicePane = new InvoicePane(messages, dbService, auditService, exchangeRateService, true);
        Scene scene = new Scene(invoicePane, 800, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        newStage.setScene(scene);
        newStage.show();
    }

    private void markPaymentReceived() {
        TextInputDialog customerDialog = new TextInputDialog();
        customerDialog.setTitle("Mark Payment");
        customerDialog.setHeaderText(messages.getString("enterCustomerName", "Enter Customer Name"));
        customerDialog.showAndWait().ifPresent(customerName -> {
            Dialog<Void> paymentDialog = new Dialog<>();
            paymentDialog.setTitle("Enter General Payment");
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField amountField = new TextField();
            ComboBox<String> currencyDropdown = new ComboBox<>();
            currencyDropdown.getItems().addAll("USD", "IQD", "RMB");
            currencyDropdown.setValue("USD");
            TextField exchangeRateField = new TextField("1.0");

            grid.add(new Label("Payment Amount:"), 0, 0);
            grid.add(amountField, 1, 0);
            grid.add(new Label("Currency:"), 0, 1);
            grid.add(currencyDropdown, 1, 1);
            grid.add(new Label("Exchange Rate (to USD):"), 0, 2);
            grid.add(exchangeRateField, 1, 2);

            paymentDialog.getDialogPane().setContent(grid);
            paymentDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

            paymentDialog.showAndWait().ifPresent(v -> {
                CompletableFuture.runAsync(() -> {
                    try {
                        double amount = Double.parseDouble(amountField.getText());
                        String currency = currencyDropdown.getValue();
                        double exchangeRate = Double.parseDouble(exchangeRateField.getText());
                        showProgress(true);
                        dbService.markPaymentReceived(customerName, amount, currency, exchangeRate, null);
                        auditService.logAction(currentUser, "payments", null, "General payment received: " + amount + " " + currency + " from " + customerName, null, null);
                        javafx.application.Platform.runLater(() -> new Alert(Alert.AlertType.INFORMATION, messages.getString("paymentReceived", "Payment Received: ") + amount + " " + currency + " from " + customerName).showAndWait());
                    } catch (Exception e) {
                        ErrorHandler.handleException(e, "Failed to mark payment", null);
                    } finally {
                        showProgress(false);
                    }
                }, executor);
            });
        });
    }

    private void changeDatabase() {
        DatabaseConfigDialog configDialog = new DatabaseConfigDialog((Stage) statusLabel.getScene().getWindow(), messages);
        configDialog.showAndWait();
        if (configDialog.isConfirmed()) {
            new Alert(Alert.AlertType.INFORMATION, messages.getString("dbConfigUpdated", "Database configuration updated")).showAndWait();
            dispose();
            launch();
        }
    }

    private void createNewDatabase() {
        TextInputDialog dbNameDialog = new TextInputDialog();
        dbNameDialog.setTitle("New Database");
        dbNameDialog.setHeaderText(messages.getString("enterNewDbName", "Enter New Database Name"));
        dbNameDialog.showAndWait().ifPresent(dbName -> {
            CompletableFuture.runAsync(() -> {
                try {
                    showProgress(true);
                    dbService.createNewDatabase(dbName);
                    auditService.logAction(currentUser, "databases", null, "Created new database: " + dbName, null, null);
                    javafx.application.Platform.runLater(() -> {
                        new Alert(Alert.AlertType.INFORMATION, messages.getString("dbCreated", "Database created: ") + dbName).showAndWait();
                        changeDatabase();
                    });
                } catch (DatabaseException e) {
                    ErrorHandler.handleException(e, messages.getString("errorCreatingDb", "Error creating database: ") + dbName, null);
                } finally {
                    showProgress(false);
                }
            }, executor);
        });
    }

    private void restrictAccessBasedOnRole(TabPane tabPane, String role) {
        if ("user".equals(role)) {
            tabPane.getTabs().get(8).setDisable(true); // Adjustments
            tabPane.getTabs().get(9).setDisable(true); // Audit Trail
        }
    }

    private void startScheduledTasks() {
        scheduler = Executors.newScheduledThreadPool(SCHEDULER_POOL_SIZE);
        scheduler.scheduleAtFixedRate(() -> {
            try {
                if (isDisposed.get()) return;
                showProgress(true);
                CompletableFuture.runAsync(() -> {
                    List<String> overduePayments = dbService.getOverduePayments(1, 100);
                    if (!overduePayments.isEmpty()) {
                        StringBuilder message = new StringBuilder(messages.getString("overduePayments", "Overdue Payments") + "\n");
                        overduePayments.forEach(payment -> message.append(payment).append("\n"));
                        javafx.application.Platform.runLater(() ->
                            new Alert(Alert.AlertType.WARNING, message.toString(), ButtonType.OK).showAndWait());
                    }
                    dbService.processRecurringInvoices();

                    List<String> reminders = dbService.getPendingReminders();
                    if (!reminders.isEmpty()) {
                        StringBuilder reminderMessage = new StringBuilder("Payment Reminders:\n");
                        reminders.forEach(reminder -> {
                            reminderMessage.append(reminder).append("\n");
                            String invoiceId = reminder.split(",")[0].split(":")[1].trim();
                            dbService.markReminderSent(invoiceId);
                        });
                        javafx.application.Platform.runLater(() ->
                            new Alert(Alert.AlertType.INFORMATION, reminderMessage.toString(), ButtonType.OK).showAndWait());
                    }
                    exchangeRateService.updateExchangeRates();
                }, executor).exceptionally(throwable -> {
                    LOGGER.error("Error in scheduled task", throwable);
                    return null;
                });
            } finally {
                showProgress(false);
            }
        }, 0, SCHEDULER_INTERVAL_MINUTES, TimeUnit.MINUTES);
    }

    private void showProgress(boolean show) {
        javafx.application.Platform.runLater(() -> {
            progressBar.setVisible(show);
            statusLabel.setText(show ? messages.getString("statusProcessing", "Processing...") : messages.getString("statusReady", "Ready"));
        });
    }

    @Override
    public void stop() {
        if (isDisposed.compareAndSet(false, true)) {
            try {
                if (scheduler != null && !scheduler.isShutdown()) scheduler.shutdownNow();
                if (executor != null && !executor.isShutdown()) executor.shutdownNow();
            } finally {
                dbService.close();
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class DatabaseConfigDialog extends Dialog<Void> {
    private static final String DEFAULT_DB_URL = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1";
    private static final String DEFAULT_USERNAME = "sa";
    private TextField urlField, usernameField;
    private PasswordField passwordField;
    private boolean confirmed = false;
    private ResourceBundle messages;

    public DatabaseConfigDialog(Stage owner, ResourceBundle messages) {
        super();
        initOwner(owner);
        setTitle(messages.getString("dbConfigTitle", "Database Configuration"));
        this.messages = messages;
        initializeUI();
    }

    private void initializeUI() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new javafx.geometry.Insets(10));

        grid.add(new Label(messages.getString("dbUrl", "Database URL:")), 0, 0);
        urlField = new TextField(DEFAULT_DB_URL);
        grid.add(urlField, 1, 0);

        grid.add(new Label(messages.getString("dbUsername", "Username:")), 0, 1);
        usernameField = new TextField(DEFAULT_USERNAME);
        grid.add(usernameField, 1, 1);

        grid.add(new Label(messages.getString("dbPassword", "Password:")), 0, 2);
        passwordField = new PasswordField();
        grid.add(passwordField, 1, 2);

        Button connectButton = new Button(messages.getString("connect", "Connect"));
        connectButton.setOnAction(e -> connect());
        grid.add(connectButton, 0, 3, 2, 1);

        getDialogPane().setContent(grid);
        getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL);
    }

    private void connect() {
        String url = urlField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();
        try {
            if (url.isEmpty() || username.isEmpty() || password.isEmpty()) {
                throw new IllegalArgumentException("All fields are required");
            }
            confirmed = true;
            close();
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Invalid database configuration: " + e.getMessage()).showAndWait();
        }
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
